# MysteryCrates
A PocketMine-MP Plugin That Adds Crates and Crate Keys.
