<?php
namespace crates;

use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\Config;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;

use crates\CratekeyCommand;

class Main extends PluginBase implements Listener {
	
	public function onEnable(){
		$this->saveDefaultConfig();
		$this->cratekey = new CratekeyCommand($this);
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
		$this->cratekey->onCommand($sender, $cmd, $label, $args);
	}
	
	public function onTouchCrate(PlayerInteractEvent $e){
		if($e->getBlock()->getId() == 54){
			if($e->getItem()->getId() == $this->getConfig()->get("cratekey-item")){
				if($e->getPlayer()->hasPermission("mysterycrates.crates.open")){
					$e->setCancelled();
					$this->openCrate($e->getPlayer());
				}
			}
		}
	}
	
	
                                    //**********************************\\
                                    //            SIMPLE API            \\
                                    //**********************************\\
	
	/*
	 * Open a crate for a player
	 */
	public function openCrate(Player $p){
		//TODO
	}
	
	/*
	 * Give a crate key to everyone on the server
	 */
	public function giveCratekeyAll(){
	        foreach($this->getServer()->getOnlinePlayers() as $p){
                       $p->getInventory()->addItem(Item::get($this->getConfig()->get("cratekey-item"), 0, 1));
	    }
	}
	
	/*
	 * Give a crate key to a player
	 */
	public function giveCrateKey(Player $p){
		$p->getInventory()->addItem(Item::get($this->getConfig()->get("cratekey-item"), 0, 1));
	}

}
