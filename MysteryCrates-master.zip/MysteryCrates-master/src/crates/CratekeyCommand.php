<?php
namespace crates;

use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\utils\TextFormat as Color;
use pocketmine\Server;
use pocketmine\Player;

use crates\Main;

class CratekeyCommand {

	public $plugin;
	private $prefix = Color::GOLD . "[" . Color::BLUE . "MysteryCrates" . Color::GOLD . "] " 
	
	public function __construct(Main $plugin) {
		$this->plugin = $plugin;
	}
	
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
		if(strtolower($cmd->getName('cratekey'))){
			if(count($args) == 0){
				$sender->sendMessage(Color::RED. "/cratekey <give/giveall>");
			}
			if(count($args) == 1){
				if($args[0] == "giveall"){
					if($sender->hasPermission("mysterycrates.command.cratekey.giveall")){
						$this->plugin->giveCratekeyAll();
						$sender->sendMessage(Color::GOLD . "You have given a cratekey to everyone on the server!");
						$sender->getServer()->broadcastMessage($this->prefix . Color::GREEN . "Everyone has been given a CrateKey by " . Color::YELLOW . $sender->getName());
					}
				}
			}
				if(count($args) == 2){
			        if($args[0] == "give"){
						if($sender->hasPermission("mysterycrates.command.cratekey.give")){
							$player = $sender->getServer()->getPlayer($args[1]);
							if($player instanceof Player){
								$player->sendMessage(Color::GREEN . "You have been given a cratekey by " . Color::YELLOW . $sender->getName());
								$sender->sendMessage(Color::GOLD . "Given a cratekey to " . Color::YELLOW . $player->getName());
								$this->plugin->giveCratekey($player);
							} else{
								$sender->sendMessage(Color::RED. "Cannot give CrateKey to offline player");
							}
						}
					}
			}
		}
	}
}
